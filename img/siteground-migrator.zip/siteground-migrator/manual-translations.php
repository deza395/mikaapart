<?php
// File created to manage some dynamic translation used in the code
// See http://keithdevon.com/using-variables-wordpress-translation-functions/

__( 'File download completed, starting site migration...', 'siteground-migrator' );